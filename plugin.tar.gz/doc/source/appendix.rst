
.. raw:: pdf

   PageBreak oneColumn


Appendix B - references
=======================

- `MidoNet Web Site <http://midonet.org/>`_
- `MidoNet v2015.06 Documentation <http://docs.midonet.org/>`_
- `MidoNet v2015.06 Code <https://github.com/midonet/midonet/tree/stable/v2015.06.3>`_
- `Midokura Enterprise MidoNet (MEM) v1.9 Documentation <http://docs.midokura.com/docs/latest/manager-guide/content/index.html>`_
- `Midokura Enterprise MidoNet (MEM) 30 Day Trial <http://www.midokura.com/mem-eval/>`_
- `Fuel Plugins Catalog <https://www.mirantis.com/products/openstack-drivers-and-plugins/fuel-plugins/>`_
