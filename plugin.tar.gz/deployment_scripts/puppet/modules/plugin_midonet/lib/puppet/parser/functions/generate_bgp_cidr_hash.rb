#    Copyright 2015 Midokura SARL, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

require 'csv'

module Puppet::Parser::Functions
  newfunction(:generate_bgp_cidr_hash, :type => :rvalue, :doc => <<-EOS
    This function returns BGP cidr CSV as an array
    EOS
  ) do |argv|
    array_of_cidrs = argv[0].parse_csv
    result = {}
    array_of_cidrs.each do |cidr|
      net_name = 'edge-subnet-' + cidr.gsub('.','').gsub('/','')
      result[net_name] = {
        'cidr' => cidr
      }
    end

    return result
  end
end
