#    Copyright 2015 Midokura SARL, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

require 'csv'

module Puppet::Parser::Functions
  newfunction(:get_node_information_static_ips, :type => :rvalue, :doc => <<-EOS
    This function returns the IP/NETNL info for passed in hostname
    EOS
  ) do |argv|
    hostname = argv[0]
    list_of_ips = argv[1]

    split_ips = list_of_ips.split(',')
    if !(list_of_ips.any? { |val| /^#{hostname}/ =~ val })
        raise "No valid IP/NETNL for hostname #{hostname}"
    end
    
    return list_of_ips.select{ |val| /#{hostname}/ =~ val }[0]

  end
end
