Puppet::Type.newtype(:midonet_router_interface) do

  desc <<-EOT
    This is currently used to model the creation of
    neutron router interfaces.

    Router interfaces are an association between a router and a
    subnet.
  EOT

  ensurable

  newparam(:name, :namevar => true) do
    desc <<-EOT
    EOT
  end

  newparam(:router_name) do
    desc 'router to which to attach this interface. '
  end

  newparam(:subnet_name) do
    desc 'subnet to which to attach this interface. '

  end

  newproperty(:id) do
    desc 'interface id. Read Only.'
    validate do |v|
      raise(Puppet::Error, 'This is a read only property')
    end
  end



  newproperty(:port) do
    desc 'An existing neutron port to which a router interface should be assigned'
  end

  autorequire(:service) do
    ['neutron-server']
  end


end
